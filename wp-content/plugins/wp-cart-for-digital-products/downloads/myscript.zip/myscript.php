<?php
// Dummy secret script
echo "Hello World!!!";

?>
